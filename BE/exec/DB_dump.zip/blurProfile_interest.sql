-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: blurProfile
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `interest`
--

DROP TABLE IF EXISTS `interest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interest` (
  `interest_name` varchar(120) NOT NULL,
  PRIMARY KEY (`interest_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interest`
--

LOCK TABLES `interest` WRITE;
/*!40000 ALTER TABLE `interest` DISABLE KEYS */;
INSERT INTO `interest` VALUES ('asmr'),('bts'),('e-스포츠'),('gta'),('J.FLA'),('LG'),('nft'),('강아지'),('갤럭시'),('거북이'),('게더타운'),('경제'),('고양이'),('곡성'),('골프'),('곰'),('공포영화'),('기후변화'),('김계란'),('김치찌개'),('냉면'),('넷플릭스'),('노트북'),('놀이공원'),('농구'),('뉴진스'),('늑대'),('닌텐도'),('다빈치코드'),('다이어트'),('당구'),('대체에너지'),('대학가'),('더 글로리'),('데스노트'),('데스크 탑'),('도수치료'),('도지코인'),('독서'),('동물간식'),('동물원'),('동화책'),('된장찌개'),('둠'),('디즈니'),('라면'),('라섹'),('라식'),('레데리'),('로맨스'),('로블록스'),('루미큐브'),('룩북'),('르세라핌'),('마라탕'),('마작'),('마크'),('매매'),('먹방'),('메타버스'),('몰래카메라'),('무협지'),('뮤지컬'),('반려동물'),('발라드'),('배드민턴'),('밴드음악'),('뱅'),('버튜버'),('보디빌딩'),('보험'),('볼링'),('부동산'),('부루마블'),('브로드웨이'),('블랙핑크'),('비염'),('비트코인'),('빈티지'),('빠니보틀'),('사이클'),('사파리'),('산책'),('삼겹살'),('삼성'),('상가'),('서점'),('섯다'),('세가'),('슈카월드'),('슈퍼마리오'),('스릴러'),('스케일링'),('스쿼시'),('스테이크'),('스트레칭'),('스트릿'),('스플렌더'),('슬램덩크'),('시카고'),('시티팝'),('식물'),('싸이타운'),('아기상어'),('아는 여자'),('아바타'),('아이브'),('아이폰'),('암호화폐'),('애견카페'),('애플'),('야구'),('야미보이'),('엑소'),('엑스박스'),('여우'),('영국남자'),('영양제'),('오버핏'),('오징어게임'),('오피스텔'),('와썹맨'),('요리'),('우노'),('우마게임'),('원피스'),('월세'),('웨어러블 '),('웹 소설'),('이더리움'),('이세돌'),('이투데이'),('이프랜드'),('인형'),('자산관리'),('자서전'),('자소서'),('잠옷'),('재테크'),('재활용'),('저축'),('전세'),('정기검진'),('정성하'),('정원'),('제네시스'),('제페토'),('젠가'),('젤다'),('젬블로'),('조깅'),('종교'),('주식'),('증권'),('지브리'),('집값'),('짜장면'),('짱구'),('쯔양'),('철권'),('체인소맨'),('초밥'),('추리'),('축구'),('치아교정'),('치킨'),('침착맨'),('카지노'),('카탄'),('캐슬배니아'),('캐주얼'),('캣츠'),('코난'),('코인'),('크로스핏'),('클라이밍'),('클루'),('킹키부츠'),('탁구'),('테니스'),('테슬라'),('테트리스'),('투자'),('파스타'),('파판'),('판타지'),('팔씨름'),('펀드'),('포탈'),('프롬'),('플스'),('피자'),('픽사'),('필라테스'),('하이킹'),('하프라이프'),('할리갈리'),('해리포터'),('햄버거'),('헬스'),('화분'),('화초'),('환경오염'),('힙합');
/*!40000 ALTER TABLE `interest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-15 13:54:54
